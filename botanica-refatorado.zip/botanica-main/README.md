# 🌿 Botânica — Comunidade Botânica ISPK

Aplicação web que preserva e partilha o saber medicinal tradicional angolano:
identificação de plantas por foto, autodiagnóstico conversacional com o
Ndembo (curandeiro virtual), um catálogo de 30 plantas com nomes em
português e Kimbundu, e ferramentas de campo para técnicos registarem o
saber dos anciãos.

## Arquitectura

```
src/
  components/
    ui/          → primitivas reutilizáveis (Button, Card, Modal, Badge…)
    layout/      → casca da aplicação (Header, SideMenu, BottomNav, PageShell)
    features/    → componentes específicos de cada funcionalidade
  pages/         → uma página por ecrã, compõem layout + features
  contexts/      → AuthContext, LanguageContext, AccessibilityContext
  services/      → supabaseClient.js, aiService.js (chamadas a /api)
  hooks/         → useGeolocation, useDisclosure, useDebouncedValue
  constants/     → ÚNICA fonte de dados: papéis, menu, plantas, tratamentos
  utils/         → geolocalização, validação
  styles/        → theme.css (tokens de design) + theme.js (espelho em JS)
api/             → funções serverless (Vercel) que chamam a Groq API
supabase/        → schema.sql opcional para contas reais
```

Cada ecrã do menu corresponde a um único componente em `src/pages/`, listado
em `PAGE_MAP` dentro de `src/App.jsx`. A navegação, os papéis com permissão
de acesso, e os textos do menu vivem **só** em `src/constants/index.js` —
não há nenhum outro sítio no código que defina um item de menu.

## Como correr localmente

```bash
npm install
cp .env.example .env.local   # depois edita o ficheiro com as tuas chaves
npm start
```

A aplicação corre em `http://localhost:3000`.

### Modo de demonstração (sem configuração)

Se `REACT_APP_SUPABASE_URL` não estiver definida, a app entra
automaticamente em **modo de demonstração**: o ecrã de login mostra três
botões — Admin, Técnico, Paciente — que iniciam sessão num clique, sem
precisar de Supabase nem de criar contas. É o estado por omissão deste
repositório, para que qualquer pessoa o possa experimentar de imediato.

### Activar contas reais (Supabase)

1. Cria um projecto em [supabase.com](https://supabase.com).
2. Corre `supabase/schema.sql` no editor SQL do teu projecto.
3. Copia o URL e a `anon key` do projecto para `.env.local`:
   ```
   REACT_APP_SUPABASE_URL=https://xxxx.supabase.co
   REACT_APP_SUPABASE_ANON_KEY=eyJ...
   ```
4. Reinicia `npm start`. O login passa a usar contas reais automaticamente.

### Activar as funcionalidades de IA (Ndembo + identificação de plantas)

As funções em `api/` correm como serverless functions na Vercel e precisam
de uma chave gratuita da Groq:

```
GROQ_API_KEY=gsk_...
```

Sem esta chave, o catálogo de plantas, os tratamentos e toda a navegação
continuam a funcionar normalmente — só o chat com o Ndembo e a
identificação por foto ficam indisponíveis.

## Deploy na Vercel

```bash
vercel
```

A Vercel detecta automaticamente o `package.json` (Create React App) e a
pasta `api/` (serverless functions). Define as variáveis de ambiente
(`GROQ_API_KEY`, `REACT_APP_SUPABASE_URL`, `REACT_APP_SUPABASE_ANON_KEY`)
no painel do projecto antes do primeiro deploy.

A app usa `HashRouter`-style navigation interna (estado em React, não
`react-router`), por isso não precisa de nenhuma configuração extra de
rewrites no `vercel.json` — qualquer hosting estático funciona.

## Decisões de design

- **Uma única paleta** (verde-floresta, dourado-acácia, terracota) definida
  em `src/styles/theme.css` — nenhum componente inventa a sua própria cor.
- **Bilingue**: português e Kimbundu, alternável em Definições.
- **Acessibilidade**: alto contraste e três tamanhos de letra, persistidos
  entre sessões.
- **Consciente da largura de banda**: a foto real de uma planta (via
  `api/plant-image.js`) só é pedida se o utilizador tocar explicitamente em
  "ver foto real" — nunca automaticamente numa lista.
- **Nunca um ecrã vazio**: toda a lista sem resultados mostra um
  `EmptyState` com uma sugestão útil, em vez de uma área branca.
